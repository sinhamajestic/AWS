import React, { useState } from "react";

export default function SmartOpsAIDashboard() {
  const [alerts, setAlerts] = useState([
    { id: 1, type: "Critical", message: "CPU usage at 95% on Server-03" },
    { id: 2, type: "Warning", message: "Disk nearing capacity on Node-07" },
    { id: 3, type: "Info", message: "Routine patch applied successfully" },
  ]);

  const [healthScore, setHealthScore] = useState(87);

  return (
    <div
      style={{
        fontFamily: "Arial, sans-serif",
        background: "linear-gradient(to bottom, #f8fafc, #e2e8f0)",
        minHeight: "100vh",
        padding: "2rem",
      }}
    >
      <h1 style={{ textAlign: "center", fontSize: "2.5rem", color: "#1e293b" }}>
        SmartOpsAI Dashboard
      </h1>
      <p
        style={{ textAlign: "center", color: "#475569", marginBottom: "2rem" }}
      >
        AI-Driven IT Operations Efficiency
      </p>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
          gap: "1.5rem",
        }}
      >
        <div
          style={{
            background: "#fff",
            borderRadius: "12px",
            padding: "1.5rem",
            boxShadow: "0 4px 8px rgba(0,0,0,0.1)",
          }}
        >
          <h2 style={{ color: "#2563eb" }}>System Health</h2>
          <p style={{ fontSize: "3rem", fontWeight: "bold", color: "#16a34a" }}>
            {healthScore}%
          </p>
          <button
            onClick={() => setHealthScore(Math.min(100, healthScore + 2))}
            style={{
              background: "#2563eb",
              color: "#fff",
              padding: "0.5rem 1rem",
              border: "none",
              borderRadius: "6px",
              cursor: "pointer",
            }}
          >
            Recalculate Health
          </button>
        </div>

        <div
          style={{
            background: "#fff",
            borderRadius: "12px",
            padding: "1.5rem",
            boxShadow: "0 4px 8px rgba(0,0,0,0.1)",
          }}
        >
          <h2 style={{ color: "#dc2626" }}>Active Alerts</h2>
          <ul style={{ listStyle: "none", padding: 0 }}>
            {alerts.map((a) => (
              <li
                key={a.id}
                style={{
                  background:
                    a.type === "Critical"
                      ? "#fee2e2"
                      : a.type === "Warning"
                      ? "#fef9c3"
                      : "#dcfce7",
                  border: "1px solid #e2e8f0",
                  borderRadius: "8px",
                  margin: "0.5rem 0",
                  padding: "0.5rem",
                }}
              >
                <strong>{a.type}: </strong>
                {a.message}
              </li>
            ))}
          </ul>
        </div>

        <div
          style={{
            background: "#fff",
            borderRadius: "12px",
            padding: "1.5rem",
            boxShadow: "0 4px 8px rgba(0,0,0,0.1)",
          }}
        >
          <h2 style={{ color: "#7c3aed" }}>Patch Automation</h2>
          <div
            style={{
              background: "#e9d5ff",
              borderRadius: "9999px",
              overflow: "hidden",
              height: "16px",
              margin: "0.5rem 0",
            }}
          >
            <div
              style={{
                width: "80%",
                background: "#7c3aed",
                height: "100%",
              }}
            ></div>
          </div>
          <p style={{ color: "#475569" }}>80% Complete</p>
        </div>
      </div>

      <footer
        style={{ textAlign: "center", marginTop: "2rem", color: "#64748b" }}
      >
        © 2025 SmartOpsAI | Hackathon Prototype
      </footer>
    </div>
  );
}
